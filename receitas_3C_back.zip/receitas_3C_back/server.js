import Fastify from 'fastify'
import {userInfo} from 'node:os';
import { Pool } from 'pg'

const sql = new Pool({
    user: "postgres",
    password: "senai",
    host: "localhost",
    port: 5432,
    database: 'receitas'
})
const servidor = Fastify()

servidor.get('/usuarios', async () => {
    const result = await sql.query('SELECT * FROM usuario')
    return result.rows;
});

servidor.delete('/usuarios:/:id', async (request, reply) => {
    const id = request.params.id;
    const resultado = await sql.query('DELETE FROM usuario WHERE id = $1', [body.nome, body.tipo, body.evolucao, id]);
});
servidor.post('/usuarios', async (request, reply) =>{
    const nome = request.body.nome;
    const senha = request.body.senha;
    const resultado = await sql.query('INSERT INTO usuario (nome, senha) VALUES ($1, $2)', [nome, senha])
return 'Usuario criado com sucesso';
});

servidor.put('/usuarios', async (request,reply) => {
    const body = request.body;
    const resultado = await sql.query('UPDATE usuario SET nome = $1, senha = $2', [body.nome, body.senha])
return 'Usuario alterado!'
});


servidor.listen({
    port: 3000
})